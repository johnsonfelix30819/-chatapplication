package db.dbprocess;
import db.connection.DbConnection;
import db.crypt.EnDe;
import server.chatserver.Message;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import java.util.Set;


public class DB 
{
	private static  Connection mycon;
	private  static Statement mystmt;
	private  static ResultSet myRs;
	

	
	public  static boolean insert(String name,String un,String pw) 
	{
		
		try 
		{
			DbConnection db=new DbConnection();
			mycon=db.getConnection();
			mystmt=db.getStatement();
			PreparedStatement ps;
			pw=EnDe.encrypt(pw);
			ps=mycon.prepareStatement("INSERT INTO logindb (name,un, pw) VALUES (?,?,?)");
			ps.setString(1,name);
			ps.setString(2,un);
			ps.setString(3,pw);
			ps.executeUpdate();
			db.close();
			return true;			
		} 
		catch (Exception e) 
		{
			System.out.println(e);
			return false;
		}
			
	}
	
	public static  int delete(String id[])
	{		
		int len=id.length;
		int rslt=0;
		if(len==0)
		{
			return 0;
		}
		else
		{
			String s=id[0];		
			for(int i=1;i<len;i++)	
			{	
				s+=","+id[i];
			}
			
			try 
			{
				DbConnection db=new DbConnection();
				mycon=db.getConnection();
				mystmt=db.getStatement();
				rslt=mystmt.executeUpdate("DELETE FROM logindb WHERE id in ("+s+");");
				db.close();
			} 
			catch (SQLException e) 
			{
				return 0;
			}
			return rslt;
		}
		
	}
	
	
	
	public static boolean validate(String dept,String un,String pw)
	{
		try
		{
			pw=EnDe.encrypt(pw);
			DbConnection db=new DbConnection();
			mycon=db.getConnection();
			mystmt=db.getStatement();
			if(dept.equals("User"))
			{	
				
				myRs=mystmt.executeQuery("SELECT * FROM logindb WHERE dept=0 AND un='"+un+"' AND pw='"+pw+"'");
			}
			else
			{
				myRs=mystmt.executeQuery("SELECT * FROM logindb WHERE dept=1 AND un='"+un+"' AND pw='"+pw+"'");
			}
			
			int size=0;
			while(myRs.next())
			{
				size++;
			}
			myRs.close();
			db.close();
			
			if(size==1)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
			return false;
		}
			
	}
	
	public static int insertMsg(String from,String to,String msg) throws Exception
	{		
		try 
		{
			DbConnection db=new DbConnection();
			mycon=db.getConnection();
			mystmt=db.getStatement();
			msg=EnDe.encrypt(msg);
			
			PreparedStatement ps;
			ps=mycon.prepareStatement("INSERT INTO `message` (`from`, `to`, `msg`) VALUES (?,?,?)");
			ps.setString(1,from);
			ps.setString(2,to);
			ps.setString(3,msg);
			ps.executeUpdate();
			db.close();
			return 1;
			
		} 
		
		catch (SQLException e) 
		{
			System.out.println(e);
			return 0;
		}
		
		
	}
	
	public static ArrayList<Message> readMsg(String from, String to,String type, int lastid)
	{
		ArrayList<Message> message=new ArrayList<Message>();
		String qry;
		String qryLId="`id` < "+lastid;
		if(lastid==0)
		{
			qryLId="true";
		}
		try
		{
			DbConnection db=new DbConnection();
			mycon=db.getConnection();
			mystmt=db.getStatement();
			
			if(type.equals("private"))
			{
				qry="Select * from (SELECT * FROM message WHERE (("+qryLId+") and ((`from`='"+from+"' and `to`='"+to+"') or (`from`='"+to+"' and `to`='"+from+"'))) ORDER BY id DESC LIMIT 50 ) sub order by id asc;";
				
			}
			else
			{
				qry="Select * from (SELECT * FROM message WHERE ("+qryLId+" and `to`='"+to+"') ORDER BY id DESC LIMIT 50 ) sub order by id asc;";
			}
			myRs=mystmt.executeQuery(qry);
			while(myRs.next())
			{
				String dbmsg=myRs.getString("msg");
				dbmsg=EnDe.decrypt(dbmsg);
				int id=Integer.parseInt(myRs.getString("id"));
				Message msg=new Message(id,dbmsg);
				message.add(msg);
			}	
			db.close();
			return message;
		}
		catch(Exception e)
		{
			System.out.println(e);
			return message;
		}
		
		
	}
	
	public static void statusUpdate(String un,int status)
	{
		try
		{	
			DbConnection db=new DbConnection();
			mycon=db.getConnection();
			mystmt=db.getStatement();
			PreparedStatement ps;
			ps=mycon.prepareStatement("UPDATE logindb SET `status` = '"+status+"' WHERE (`un` = '"+un+"');");
			ps.executeUpdate();
			ps.close();
			db.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
			
	}
	
	public static HashSet<String> statusRead()
	{
		HashSet<String> user = new HashSet<String>();
		try
		{
			DbConnection db=new DbConnection();
			mycon=db.getConnection();
			mystmt=db.getStatement();
			myRs=mystmt.executeQuery("SELECT * FROM logindb WHERE status='0' ");
			while(myRs.next())
			{
				user.add(myRs.getString("un"));
			}
			db.close();
			return user;
		}
		catch(Exception e)
		{
			System.out.println(e);
			return user;
		}
				
	}
	
	

}