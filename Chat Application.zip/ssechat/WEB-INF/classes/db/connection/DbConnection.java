package db.connection;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
public class DbConnection 
{
	private  Connection mycon;
	private  Statement mystmt;
	
	
	public Connection getConnection()
	{
		try
		{
			final String url="jdbc:mysql://localhost:3306/john";
			final String dbUserName="root";
			final String dbPassword="root";
			Class.forName("com.mysql.cj.jdbc.Driver");
			mycon=DriverManager.getConnection(url,dbUserName,dbPassword);
		}
		catch(ClassNotFoundException | SQLException e)
		{
			System.out.println(e);
		}
		return mycon;
	}
	
	
	public Statement getStatement() throws SQLException
	{
		mystmt=mycon.createStatement();
		return mystmt;
	}
	
	public void close() throws SQLException
	{
		mystmt.close();
		mycon.close();
	}
	
	

}

