package db.crypt;

import java.security.Key;
import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;

public class EnDe {
	
	
	private static final String ALGO="AES";
	private static String publicKey="asdjfkjsdfoifnfv";
	private static byte[] keyValue=publicKey.getBytes();;
	

	public  static String encrypt(String data)throws Exception
	{
		Key key=generateKey();
		Cipher c=Cipher.getInstance(ALGO);
		c.init(Cipher.ENCRYPT_MODE, key);
		byte[] encVal=c.doFinal(data.getBytes());
		String encryptValue=Base64.getEncoder().encodeToString(encVal);
		return encryptValue;
	}
	
	
	public static String decrypt(String data)throws Exception
	{
		Key key=generateKey();
		Cipher c=Cipher.getInstance(ALGO);
		c.init(Cipher.DECRYPT_MODE, key);
		byte[] decVal=Base64.getDecoder().decode(data);
		String decodedValue=new String(c.doFinal(decVal));
		return decodedValue;
	}
	
	
	private static Key generateKey() {
		
		Key key=new SecretKeySpec(keyValue,ALGO);
		return key;
	}

}
