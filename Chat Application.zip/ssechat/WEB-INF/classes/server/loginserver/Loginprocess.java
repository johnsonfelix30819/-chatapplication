package server.loginserver;
import db.dbprocess.DB;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpSession;

@WebServlet("/loginprocess")
public class Loginprocess extends HttpServlet 
{
		  
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		HttpSession ses=req.getSession();
		String action=(String)ses.getAttribute("action");
		String dept=(String)ses.getAttribute("dept");
		String username=(String)ses.getAttribute("username");
		String user=req.getParameter("user");
		String pass=req.getParameter("pass");
		String name=req.getParameter("name");
		
		switch(action)
		{
			case "login":
				if(DB.validate(dept,user,pass))
				{
					if(dept.equals("User"))
					{
						ses.setAttribute("username", user);
						res.sendRedirect("welcome.jsp");
					}
					else if(dept.equals("Admin"))
					{
						ses.setAttribute("user", user);
						res.sendRedirect("adminpage.jsp");
					}
				}
				else
				{
					ses.setAttribute("msg", "Invalid Username or Password");
					res.sendRedirect("index.jsp");
				}
				break;
				
			case "register":
				if(DB.insert(name,user,pass))
				{
					ses.setAttribute("msg", "!Registration Successfull!");
					ses.removeAttribute("action");
					res.sendRedirect("index.jsp");
				}
				else
				{
					ses.setAttribute("msg", "!User Name Already Exists, Try Another!");
					res.sendRedirect("register.jsp");
				}
				break;
				
			case "delete":
				int m=0;
				try 
				{
					String id[]=req.getParameterValues("usr");
					m=DB.delete(id);
				}
				catch(Exception e) 
				{
					m=0;
				}
				if(m==0)
				{
					ses.setAttribute("msg", "Select Users to Delete");
					res.sendRedirect("adminpage.jsp");
				}
				else
				{
					ses.setAttribute("msg", m+"-Users deleted Successfully");
					res.sendRedirect("adminpage.jsp");
					
				}
				break;
			default:
				ses.setAttribute("msg", "Unexpected Error Occured, Try After Some Time");
				res.sendRedirect("index.jsp");

		}
	}
		
}
