package server.chatserver;
import server.chatserver.ChatServer;
import javax.servlet.AsyncContext;
import javax.servlet.AsyncEvent;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
public class MessageProcess
{
	
public void removeUser(String user)
	{
		System.out.println("i love u  "+user);
		for (AsyncContext asyc : ChatServer.asyncContexts.values())
			{
				HttpSession ses=((HttpServletRequest)asyc.getRequest()).getSession();
				String username=(String)ses.getAttribute("username");
				System.out.println("user in the session"+username);
				if(username .equals(user)) 
				{
					System.out.println("remove user");
					ChatServer.asyncContexts.values().remove(asyc);
					ChatServer.userSession();
				}
			}
	}

}