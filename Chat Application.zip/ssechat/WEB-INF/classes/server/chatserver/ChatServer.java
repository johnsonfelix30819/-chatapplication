package server.chatserver;

import db.dbprocess.DB;
import java.sql.SQLException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonArrayBuilder;
import javax.json.JsonWriter;

import javax.servlet.AsyncContext;
import javax.servlet.AsyncEvent;
import javax.servlet.AsyncListener;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

@WebServlet("/chatserver")
public class ChatServer extends HttpServlet 
{
		
	private static Map<String, AsyncContext> asyncContexts = new ConcurrentHashMap<String, AsyncContext>();
	private BlockingQueue<Message> messageQueue = new LinkedBlockingQueue<Message>();
	private ArrayList<Message> msgId=new ArrayList<Message>();
	private ArrayList<Message> pmsgId=new ArrayList<Message>();
	private static int count;
	private Thread sse = new Thread(new Runnable() 
	{

		@Override
		public void run() 
		{
			while(true)
			{
					
				
					try {
						Message message = messageQueue.take();
						for (AsyncContext asyc : asyncContexts.values()) 
						{
							try 
							{
								sendMessage(asyc.getResponse().getWriter(),message);
								asyc.getResponse().flushBuffer();
							}
							catch(IOException e)
							{
								System.out.println("close on exception");
								asyncContexts.values().remove(asyc);
								userSession();
							}
						}
						
						
					} 
					catch (InterruptedException e) 
					{
						System.out.println(e);
					}
			}
		}
	});
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		sse.start();
		count=0;
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		request.setAttribute("org.apache.catalina.ASYNC_SUPPORTED", true);
		response.setContentType("text/event-stream");
		response.setHeader("Cache-Control", "no-cache");
		response.setHeader("Connection", "keep-alive");
		response.setCharacterEncoding("UTF-8");
		
		final String id = UUID.randomUUID().toString();
		final AsyncContext ac = request.startAsync(request,response);
		ac.setTimeout(0);
		asyncContexts.put(id, ac);
		Message msg=new Message(count++,"public-Connected to server");
		sendMessage(response.getWriter(),msg);
		response.flushBuffer();
		
		
		
		HttpSession ses=request.getSession();
		String fromUser=(String)ses.getAttribute("username");
		sendOldMessage(fromUser,"public","first");
//user update	
		
			DB.statusUpdate(fromUser,1);
			userSession();

		
	}

// post method to get message from client
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		request.setCharacterEncoding("UTF-8");
		String message=request.getParameter("msg");
		HttpSession ses=request.getSession();
		String username=(String)ses.getAttribute("username");
		
		String part[]=message.split("-",2);
		if(part[0].equals("private"))
		{
			String parts[]=part[1].split("-",3);
			String fromUser=parts[0];
			String toUser=parts[1];
			String msgs=parts[2];
			
			try
				{
					DB.insertMsg(fromUser,toUser,username+" :  "+msgs);
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
			
			message=part[0]+"-"+fromUser+"-"+toUser+"-"+fromUser+"  :  "+msgs;
		}
		else if(part[0].equals("oldmsg"))
		{
			String parts[]=part[1].split("-",2);
			String fromUser=parts[0];
			String toUser=parts[1];
			sendOldMessage(fromUser,toUser,"first");
		}
		else if(part[0].equals("moreMsg"))
		{
			String parts[]=part[1].split("-",2);
			String fromUser=parts[0];
			String toUser=parts[1];
			sendOldMessage(fromUser,toUser,"moreMsg");
		}
		else
		{	try
				{
					DB.insertMsg(username,"public",username+" :  "+part[1]);
					
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
			
			message=part[0]+"-"+username+"  :  "+part[1];
		}
		
		Message msg = new Message(count++, jsondata(message));
		try 
		{
			
			messageQueue.put(msg);
		}
		catch (InterruptedException e) 
		{
			
		}
		
	}
// send old message to the client	
	public void sendOldMessage(String fromUser, String toUser, String type)
	{
		
		ArrayList<Message> dbMessage;
		int lastid=0;
		if(type.equals("moreMsg"))
		{
			if(toUser.equals("public"))
			{
				for(Message msg : msgId)
				{
					if(msg.getMessage().equals(fromUser))
					{
						lastid=(int)msg.getId();
						msgId.remove(msg);
						break;
					}
				}
			}
			else
			{
				for(Message msg : msgId)
				{
					if(msg.getMessage().equals(fromUser))
					{
						lastid=(int)msg.getId();
						pmsgId.remove(msg);
						break;
					}
				}
			}
			
		}
		
		
		try
			{
				
				if(toUser.equals("public"))
				{
					
					dbMessage=DB.readMsg(fromUser,toUser,"public",lastid);
				}
				else
				{
					
					dbMessage=DB.readMsg(fromUser,toUser,"private",lastid);
				}
				
				
				
					for (AsyncContext asyc : asyncContexts.values())
					{
						
						try 
						{
							HttpSession ses=((HttpServletRequest)asyc.getRequest()).getSession();
							String username=(String)ses.getAttribute("username");
							if(username.equals(fromUser))
							{
								boolean check=true;
								for(Message i : dbMessage)
								{
									String msg=i.getMessage();
									long id=i.getId();
									Message message;
									
									if(toUser.equals("public"))
									{
										if(check)
										{
											
											message=new Message(id,username);
											msgId.add(message);
											check=false;
										}
										message = new Message(id, jsondata(toUser+"-"+msg));
									}
									else
									{
										if(check)
										{
											message=new Message(id,username);
											pmsgId.add(message);
											check=false;
										}
										message = new Message(id, jsondata("private"+"-"+fromUser+"-"+toUser+"-"+msg));
									}
									
									sendMessage(asyc.getResponse().getWriter(),message);
									asyc.getResponse().flushBuffer();
								}
								break;
							}									
						
						}
						catch(IOException e)
						{
							System.out.println(e);
							userSession();
							asyncContexts.values().remove(asyc);
						}
										
					}
					
					
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
	}
	
// sends online users to all clients	
	protected static void userSession() 
	{
		
		Message message=new Message(count++,jsonuser());
		for (AsyncContext asyc : asyncContexts.values())
		{
			try 
			{				
				sendMessage(asyc.getResponse().getWriter(),message);
				asyc.getResponse().flushBuffer();
			}
			catch(IOException e)
			{
				System.out.println(e);
				asyncContexts.values().remove(asyc);
			}
			
		}
	}
	
	
	private static String jsonuser() 

	{
		JsonObjectBuilder job=Json.createObjectBuilder();
		
		Iterator<String> ite=onlineChatUserName().iterator();
		JsonArrayBuilder js=Json.createArrayBuilder();
		while(ite.hasNext())
		{
			js.add((String)ite.next());
		}
		JsonArrayBuilder js1=Json.createArrayBuilder();
		try{
		Iterator<String> ite1=chatUserName().iterator();
		while(ite1.hasNext())
		{
			js1.add((String)ite1.next());
		}
		}catch(SQLException e){}
		job.add("onlineuser",js);
		job.add("user",js1);
		return job.build().toString();
	}
	
//online user	
	private static Set<String> onlineChatUserName() 
	{
		HashSet<String> returnSet = new HashSet<String>();
					
			for (AsyncContext asyc : asyncContexts.values())
			{
				HttpSession ses=((HttpServletRequest)asyc.getRequest()).getSession();
				String username=(String)ses.getAttribute("username");
				if(username != null) 
				{
					returnSet.add(username);
				}
			}
		return returnSet;
	}
//offline user	
	private static Set<String> chatUserName() throws SQLException
	{
		HashSet<String> returnSet = new HashSet<String>();

			returnSet=DB.statusRead();
	
		return returnSet;
	}
	
	private String jsondata(String message)
	{
		JsonObject jb=Json.createObjectBuilder().add("message",message).build();
		return jb.toString();
	}
	
//remove online user
	public static void  removeUser(String user)
	{
		for (AsyncContext asyc : asyncContexts.values())
			{
				HttpSession ses=((HttpServletRequest)asyc.getRequest()).getSession();
				String username=(String)ses.getAttribute("username");
				
				if(username .equals(user)) 
				{
					asyncContexts.values().remove(asyc);
					userSession();
					break;
				}
			}
	}
	
// send message through SSE
	protected static void sendMessage(PrintWriter pw,Message message)
	{
		pw.print("id:"+message.getId()+"\n");
		pw.print("data:"+message.getMessage()+"\n\n");
	}

}
